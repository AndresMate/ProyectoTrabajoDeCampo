export default function DashboardPage() {
  return (
    <section>
      <h1 className="text-2xl font-bold mb-4">Bienvenido al Panel</h1>
      <p className="text-gray-700">Aquí podrás gestionar torneos, usuarios, equipos y más.</p>
    </section>
  );
}
